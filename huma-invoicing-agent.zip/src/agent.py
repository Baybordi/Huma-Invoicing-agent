"""
agent.py — The orchestrator. This is the agent's control loop.

It wires the four stages into one pipeline and is the single entry point you run
for the demo:

    ingest PDFs  ->  extract (LLM + guardrail)  ->  validate (business rules)
                 ->  route:  POST  -> create bill in Odoo + audit log
                             FLAG  -> record for human review, do not post

Design notes for the interview:
  - The pipeline is explicit and inspectable. Each invoice carries its state
    (extracted data, decision, reasons, outcome) through to a final report.
  - "Fail closed": anything we are unsure about becomes a FLAG, never a silent
    auto-post. The human-in-the-loop is the default for ambiguity.
  - Odoo connection is lazy: we only require a live ERP when something actually
    needs posting, so the extract/validate stages can run (and be demoed/tested)
    without Odoo up. Pass --dry-run to skip Odoo entirely.

  - The inbox is mocked as a folder of PDFs (data/invoices). The brief explicitly
    allows this. Swapping in a real IMAP/Graph poller would replace only
    `iter_invoice_files` — nothing else changes. That is the point of the seam.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
from dataclasses import asdict, dataclass

from anthropic import Anthropic

from .config import Settings, load_settings
from .extract import extract_invoice, read_pdf_text
from .odoo_client import OdooClient
from .schema import ExtractedInvoice
from .validate import (
    ApprovedSupplier,
    Decision,
    ValidationResult,
    load_approved_suppliers,
    validate_invoice,
)

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s"
)
logger = logging.getLogger("agent")


@dataclass
class InvoiceOutcome:
    source_file: str
    vendor: str | None = None
    invoice_number: str | None = None
    decision: str | None = None
    reasons: list[str] | None = None
    bill_id: int | None = None
    error: str | None = None


def iter_invoice_files(folder: str) -> list[str]:
    """The mocked 'inbox'. Real implementation would poll IMAP/Graph and filter
    for application/pdf attachments — same return shape, swappable in isolation."""
    return sorted(
        os.path.join(folder, f)
        for f in os.listdir(folder)
        if f.lower().endswith(".pdf")
    )


def run(
    invoices_dir: str,
    supplier_list_path: str,
    dry_run: bool = False,
) -> list[InvoiceOutcome]:
    settings = load_settings()
    client = Anthropic(api_key=settings.anthropic_api_key)
    approved = load_approved_suppliers(supplier_list_path)
    logger.info("Loaded %d approved suppliers", len(approved))

    odoo: OdooClient | None = None  # connect lazily, only if we post

    seen: set[tuple[str, str | None]] = set()
    outcomes: list[InvoiceOutcome] = []

    for path in iter_invoice_files(invoices_dir):
        filename = os.path.basename(path)
        outcome = InvoiceOutcome(source_file=filename)
        logger.info("Processing %s", filename)

        # --- Stage 3: extract -------------------------------------------------
        try:
            text = read_pdf_text(path)
            invoice = extract_invoice(text, client, settings, source_file=filename)
        except Exception as exc:  # extraction failed even after retry
            outcome.decision = Decision.FLAG.value
            outcome.reasons = [f"Extraction failed: {exc}"]
            outcomes.append(outcome)
            logger.error("Extraction failed for %s: %s", filename, exc)
            continue

        outcome.vendor = invoice.vendor
        outcome.invoice_number = invoice.invoice_number

        # --- Stage 4a: validate ----------------------------------------------
        result: ValidationResult = validate_invoice(invoice, approved, seen)
        outcome.decision = result.decision.value
        outcome.reasons = result.reasons
        seen.add((invoice.vendor.strip().lower(), invoice.invoice_number))

        # --- Stage 4b: route --------------------------------------------------
        if result.decision == Decision.POST:
            if dry_run:
                logger.info("[dry-run] would POST %s", filename)
            else:
                if odoo is None:
                    odoo = OdooClient(settings)
                post = odoo.post_bill(invoice)
                if post.ok:
                    outcome.bill_id = post.bill_id
                else:
                    # Odoo refused (e.g. vendor record missing) — becomes a FLAG.
                    outcome.decision = Decision.FLAG.value
                    outcome.reasons = (outcome.reasons or []) + [post.error]

        outcomes.append(outcome)

    _print_summary(outcomes, dry_run)
    return outcomes


def _print_summary(outcomes: list[InvoiceOutcome], dry_run: bool) -> None:
    posted = [o for o in outcomes if o.bill_id is not None]
    flagged = [o for o in outcomes if o.decision == Decision.FLAG.value]
    dry_posts = [
        o for o in outcomes if dry_run and o.decision == Decision.POST.value
    ]

    print("\n" + "=" * 70)
    print("INVOICING AGENT — RUN SUMMARY")
    print("=" * 70)
    for o in outcomes:
        if o.bill_id is not None:
            status = f"POSTED  (Odoo bill #{o.bill_id})"
        elif dry_run and o.decision == Decision.POST.value:
            status = "POST    (dry-run, not sent)"
        else:
            status = "FLAGGED"
        print(f"\n• {o.source_file}")
        print(f"    vendor : {o.vendor}")
        print(f"    number : {o.invoice_number}")
        print(f"    result : {status}")
        for reason in o.reasons or []:
            print(f"      - {reason}")

    print("\n" + "-" * 70)
    print(
        f"Total: {len(outcomes)}  |  "
        f"Posted: {len(posted)}{' (dry-run: ' + str(len(dry_posts)) + ')' if dry_run else ''}  |  "
        f"Flagged for human review: {len(flagged)}"
    )
    print("=" * 70 + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Huma automated invoicing agent")
    parser.add_argument("--invoices", default="data/invoices")
    parser.add_argument("--suppliers", default="data/Approved_Supplier_List.xlsx")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Run extract + validate only; do not connect to or post to Odoo.",
    )
    parser.add_argument(
        "--out",
        default=None,
        help="Optional path to write the run outcomes as JSON.",
    )
    args = parser.parse_args()

    outcomes = run(args.invoices, args.suppliers, dry_run=args.dry_run)

    if args.out:
        with open(args.out, "w") as f:
            json.dump([asdict(o) for o in outcomes], f, indent=2)
        logger.info("Wrote outcomes to %s", args.out)


if __name__ == "__main__":
    main()
